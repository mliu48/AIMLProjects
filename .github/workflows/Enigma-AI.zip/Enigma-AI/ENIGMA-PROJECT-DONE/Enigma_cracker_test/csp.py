#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
基于原始代码改造的GUI版加解密程序
"""

import tkinter as tk
from tkinter import ttk, messagebox
from tools import swap_connector, set_sequence, list_move, list_reverse, str_to_list

# 初始转子与反射器列表（后续每次运行前都会重置）
init_list1 = ['E', 'M', 'F', 'G', 'H', 'I', 'J', 'A', 'B', 'C', 'D', 'K', 'L']
init_list2 = ['N', 'Y', 'Z', 'O', 'T', 'U', 'V', 'P', 'Q', 'R', 'S', 'W', 'X']
init_list3 = ['Z', 'A', 'F', 'G', 'B', 'H', 'I', 'C', 'D', 'J', 'X', 'Y', 'E']
init_list4 = ['K', 'L', 'Q', 'M', 'T', 'R', 'S', 'U', 'V', 'N', 'O', 'P', 'W']
init_list5 = ['P', 'X', 'Q', 'W', 'S', 'T', 'V', 'U', 'Y', 'Z', 'A', 'R', 'B']
init_list6 = ['C', 'M', 'N', 'O', 'D', 'K', 'F', 'G', 'E', 'H', 'I', 'J', 'L']
init_reflect_list = ['T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'A', 'B', 'C', 'D', 'E', 'F']
init_reflect_list_1 = ['G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S']

# 全局变量（后续会根据配置修改）
list1 = init_list1.copy()
list2 = init_list2.copy()
list3 = init_list3.copy()
list4 = init_list4.copy()
list5 = init_list5.copy()
list6 = init_list6.copy()
reflect_list = init_reflect_list.copy()
reflect_list_1 = init_reflect_list_1.copy()

ec1 = []
ec2 = []
ec3 = []
ec4 = []
ec5 = []
ec6 = []
ec_rl = [] 
ec_rl1 = []

Enc1 = {}
Enc2 = {}
Enc3 = {}
Reflector = {}

# 转子起始字母（用于转子移动判断）
Se1 = ''
Se2 = ''
Se3 = ''

#———— 工具函数 —————
def def_swap(w, arr):
    i = arr.index(w)
    list_move(arr, i)

def detect1(w):
    if w in list1:
        def_swap(list2[list1.index(w)], list2)
        def_swap(w, list1)
    else:
        def_swap(list1[list2.index(w)], list1)
        def_swap(w, list2)

def detect2(w):
    if w in list3:
        def_swap(list4[list3.index(w)], list4)
        def_swap(w, list3)
    else:
        def_swap(list3[list4.index(w)], list3)
        def_swap(w, list4)

def detect3(w):
    if w in list5:
        def_swap(list6[list5.index(w)], list6)
        def_swap(w, list5)
    else:
        def_swap(list5[list6.index(w)], list5)
        def_swap(w, list6)

def set_ini(ini):
    global Se1, Se2, Se3
    w1 = ini[0]
    detect1(w1)
    Se1 = w1
    w2 = ini[1]
    detect2(w2)
    Se2 = w2
    w3 = ini[2]
    detect3(w3)
    Se3 = w3

# 转子顺序调整
def setseq(seq):
    global list1, list2, list3, list4, list5, list6
    l_12 = list1 + list2
    l_34 = list3 + list4
    l_56 = list5 + list6
    l_12, l_34, l_56 = set_sequence(seq[0], seq[1], seq[2], l_12, l_34, l_56)
    list1, list2 = l_12[0:13], l_12[13:]
    list3, list4 = l_34[0:13], l_34[13:]
    list5, list6 = l_56[0:13], l_56[13:]

# 交换接线板（接线板交换配置采用成对字母，如"AB"表示A与B交换）
def swap(w1, w2):
    global list1, list2, list3, list4, list5, list6, reflect_list, reflect_list_1, init_list1, init_list2, init_list3, init_list4, init_list5, init_list6, init_reflect_list, init_reflect_list_1
    if w1 in alphaet and w2 in alphaet:
        # 对 l12
        i1 = (init_list1 + init_list2).index(w1)
        i2 = (init_list1 + init_list2).index(w2)
        list1, list2 = swap_connector(i1, i2, init_list1 + init_list2)
        # 对 l34
        i1 = (init_list3 + init_list4).index(w1)
        i2 = (init_list3 + init_list4).index(w2)
        list3, list4 = swap_connector(i1, i2, init_list3 + init_list4)
        # 对 l56
        i1 = (init_list5 + init_list6).index(w1)
        i2 = (init_list5 + init_list6).index(w2)
        list5, list6 = swap_connector(i1, i2, init_list5 + init_list6)
        # 对反射器
        i1 = (init_reflect_list + init_reflect_list_1).index(w1)
        i2 = (init_reflect_list + init_reflect_list_1).index(w2)
        reflect_list, reflect_list_1 = swap_connector(i1, i2, init_reflect_list + init_reflect_list_1)
    else:
        print("Invalid input || 无效输入")
        return

def set_plug(swapped):
    # swapped为字符串，例如 "ABCEDK" 表示 AB、CE、DK 三组交换
    # 此处按每两位进行交换
    for i in range(0, len(swapped) - 1, 2):
        w1 = swapped[i]
        w2 = swapped[i+1]
        swap(w1, w2)

#———— 生成转子映射 —————
def generate_Enc():
    global Enc1, Enc2, Enc3, Reflector
    Enc1 = {}
    Enc2 = {}
    Enc3 = {}
    Reflector = {}
    for i in range(0, 13):
        Enc1[ec1[i]] = ec2[i]
        Enc1[ec2[i]] = ec1[i]

        Enc2[ec3[i]] = ec4[i]
        Enc2[ec4[i]] = ec3[i]

        Enc3[ec5[i]] = ec6[i]
        Enc3[ec6[i]] = ec5[i]

        Reflector[ec_rl[i]] = ec_rl1[i]
        Reflector[ec_rl1[i]] = ec_rl[i]

#———— 加解密核心函数 —————
# 注意：加密与解密过程完全对称
def encryption(text):
    global ec1, ec2, ec3, ec4, ec5, ec6, ec_rl, ec_rl1, ans
    ans = []  # 每次处理前清空答案
    text = str_to_list(text)
    F = True
    while text:
        w = text.pop(0)
        # 保留标点及空格
        if w in [',', ' ', '.']:
            ans.append(w)
        else:
            if F:
                # 第一次处理时记录转子当前状态
                ec1 = list1.copy()
                ec2 = list2.copy()
                ec3 = list3.copy()
                ec4 = list4.copy()
                ec5 = list5.copy()
                ec6 = list6.copy()
                ec_rl = reflect_list.copy()
                ec_rl1 = reflect_list_1.copy()
                F = False
                generate_Enc()
                # 从一号转子开始依次过三转子、反射器，再反向回去
                w = Enc1[w]
                w = Enc2[w]
                w = Enc3[w]
                w = Reflector[w]
                w = Enc3[w]
                w = Enc2[w]
                w = Enc1[w]
                ans.append(w)
                # 一号转子转动一步
                ec1 = list_move(ec1, 1)
            else:
                generate_Enc()
                w = Enc1[w]
                w = Enc2[w]
                w = Enc3[w]
                w = Reflector[w]
                w = Enc3[w]
                w = Enc2[w]
                w = Enc1[w]
                ans.append(w)
                ec1 = list_move(ec1, 1)
                # 判断转子是否到达“翻转点”
                if ec1[0] == Se1:
                    list_move(ec3, 1)
                    if ec3[0] == Se2:
                        list_move(ec5, 1)
                        if ec5[0] == Se3:
                            list_move(ec_rl, 1)
    return ''.join(ans)

#———— GUI处理函数 —————
alphaet = [chr(i) for i in range(65, 91)]  # 字母A~Z

def on_run():
    # 每次运行前重置全局列表（保证每次使用相同配置）
    global list1, list2, list3, list4, list5, list6, reflect_list, reflect_list_1
    list1 = init_list1.copy()
    list2 = init_list2.copy()
    list3 = init_list3.copy()
    list4 = init_list4.copy()
    list5 = init_list5.copy()
    list6 = init_list6.copy()
    reflect_list = init_reflect_list.copy()
    reflect_list_1 = init_reflect_list_1.copy()

    # 获取模式（虽然加解密过程对称，但可显示用户选择）
    mode = mode_var.get()
    rotor_seq_str = rotor_seq_entry.get().strip()
    rotor_ini_str = rotor_ini_entry.get().strip().upper()
    plug_str = plug_entry.get().strip().upper()
    input_text = text_input.get("1.0", tk.END).strip()

    if not (rotor_seq_str and rotor_ini_str and plug_str and input_text):
        messagebox.showwarning("提示", "请完整填写所有配置项及文本")
        return

    # 解析转子顺序（例如 "123" 会变成 [1,2,3]）
    try:
        seq = [int(x) for x in rotor_seq_str]
        if len(seq) != 3:
            raise ValueError
    except Exception as e:
        messagebox.showerror("错误", "转子顺序格式错误，应为3位数字，如123")
        return

    # 解析转子初始字母（应为3个字母，如"AAA"）
    if len(rotor_ini_str) != 3:
        messagebox.showerror("错误", "转子起始字母应为3个字母，如AAA")
        return
    ini = list(rotor_ini_str)

    # plug_str 的长度应为偶数，表示交换对（例如 "ABCEDK" 表示 AB、CE、DK）
    if len(plug_str) % 2 != 0:
        messagebox.showerror("错误", "交换接线板配置字母数应为偶数")
        return
    swapped = list(plug_str)

    # 根据配置初始化各部分
    setseq(seq)
    set_ini(ini)
    set_plug(swapped)

    # 执行加解密（注意此处加解密过程相同）
    result = encryption(input_text)
    # 在输出框中显示结果
    text_output.delete("1.0", tk.END)
    text_output.insert(tk.END, result)
    # 显示加/解密模式（可选）
    lbl_mode_result.config(text=f"【{mode}结果】")

#———— 构建GUI界面 —————
root = tk.Tk()
root.title("加解密程序")

mainframe = ttk.Frame(root, padding="10")
mainframe.grid(row=0, column=0, sticky=(tk.N, tk.W, tk.E, tk.S))

# 模式选择
mode_var = tk.StringVar(value="加密")
ttk.Label(mainframe, text="请选择模式：").grid(row=0, column=0, sticky=tk.W)
mode_frame = ttk.Frame(mainframe)
mode_frame.grid(row=0, column=1, sticky=tk.W)
for m in ("加密", "解密"):
    ttk.Radiobutton(mode_frame, text=m, variable=mode_var, value=m).pack(side=tk.LEFT)

# 转子顺序配置
ttk.Label(mainframe, text="转子顺序 (例: 123):").grid(row=1, column=0, sticky=tk.W)
rotor_seq_entry = ttk.Entry(mainframe, width=10)
rotor_seq_entry.grid(row=1, column=1, sticky=tk.W)

# 转子起始字母配置
ttk.Label(mainframe, text="转子起始字母 (例: AAA):").grid(row=2, column=0, sticky=tk.W)
rotor_ini_entry = ttk.Entry(mainframe, width=10)
rotor_ini_entry.grid(row=2, column=1, sticky=tk.W)

# 交换接线板配置
ttk.Label(mainframe, text="交换接线板 (成对字母, 例: ABCEDK):").grid(row=3, column=0, sticky=tk.W)
plug_entry = ttk.Entry(mainframe, width=15)
plug_entry.grid(row=3, column=1, sticky=tk.W)

# 输入文本
ttk.Label(mainframe, text="请输入待处理文本：").grid(row=4, column=0, sticky=tk.W)
text_input = tk.Text(mainframe, width=60, height=8)
text_input.grid(row=5, column=0, columnspan=2, pady=5)

# 输出文本
lbl_mode_result = ttk.Label(mainframe, text="【结果】", font=("Arial", 10, "bold"))
lbl_mode_result.grid(row=6, column=0, sticky=tk.W)
text_output = tk.Text(mainframe, width=60, height=8)
text_output.grid(row=7, column=0, columnspan=2, pady=5)

# 运行按钮
run_button = ttk.Button(mainframe, text="运行", command=on_run)
run_button.grid(row=8, column=0, columnspan=2, pady=10)

root.mainloop()
