import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import re
import joblib
from nltk.corpus import stopwords
from sklearn.metrics import accuracy_score, classification_report
STOPWORDS = set(stopwords.words('english'))

# 创建清洗文本数据的函数
def clean_text(text):
    clean_text = re.sub('[\[\]!@#$(),\n"%^*?\:;~`0-9]', ' ', text)   #去除不需要的符号
    clean_text = clean_text.lower()   # 转换为小写
    clean_text = ' '.join(word for word in  clean_text.split() if word not in STOPWORDS)  # 删除停用词 
    
    return clean_text


def get_confidence_score(text):
    text_sequences = tokenizer.texts_to_sequences([text])
    text_padded = tf.keras.preprocessing.sequence.pad_sequences(text_sequences, maxlen=max_length)
    scores = model.predict(text_padded)[0]
    confidence_score = scores[np.argmax(scores)]
    return confidence_score

# 读取数据集
dataset = pd.read_csv('Language_Detection.csv', encoding='utf-8')
X = dataset['Text'].apply(clean_text)
y = dataset['Language']

# 对标签进行编码
encoder = LabelEncoder()
y = encoder.fit_transform(y)
joblib.dump(encoder, 'encoder.pkl')

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, shuffle=True, random_state=777)

# 构建TensorFlow模型
max_features = 10000  # 设置词汇表中最大单词数量
max_length = 100  # 设置输入文本的最大长度

# 创建Tokenizer对象，对文本进行分词
tokenizer = tf.keras.preprocessing.text.Tokenizer(num_words=max_features)
tokenizer.fit_on_texts(X_train)
joblib.dump(tokenizer, 'tokenizer.pkl')
# 将文本转换为序列
X_train_sequences = tokenizer.texts_to_sequences(X_train)
X_test_sequences = tokenizer.texts_to_sequences(X_test)

# 对序列进行填充，使其长度一致
X_train_padded = tf.keras.preprocessing.sequence.pad_sequences(X_train_sequences, maxlen=max_length)
X_test_padded = tf.keras.preprocessing.sequence.pad_sequences(X_test_sequences, maxlen=max_length)

# 构建模型
model = tf.keras.models.Sequential([
    tf.keras.layers.Embedding(max_features, 64, input_length=max_length),
    tf.keras.layers.Bidirectional(tf.keras.layers.GRU(128, return_sequences=True)),
    tf.keras.layers.GlobalMaxPooling1D(),
    tf.keras.layers.Dense(64, activation='relu'),
    tf.keras.layers.Dense(len(encoder.classes_), activation='softmax')
])

# 编译模型
model.compile(loss='sparse_categorical_crossentropy', optimizer=tf.keras.optimizers.Adam(), metrics=['accuracy'])

# 训练模型
model.fit(X_train_padded, y_train, validation_data=(X_test_padded, y_test), epochs=60, batch_size=32)

# 在测试集上评估模型
y_pred = np.argmax(model.predict(X_test_padded), axis=-1)

# 输出准确率和分类报告
print('accuracy %s' % accuracy_score(y_pred, y_test))
print(classification_report(y_test, y_pred, target_names=encoder.classes_))

# 保存模型
model.save('language_detection_model.h5')

# 使用训练好的模型对新样本进行预测
while True:
    text = input("Enter a text: ")
    text_sequences = tokenizer.texts_to_sequences([text])
    text_padded = tf.keras.preprocessing.sequence.pad_sequences(text_sequences, maxlen=max_length)
    y = np.argmax(model.predict(text_padded), axis=-1)
    prediction = encoder.classes_[y]

    print(prediction)
    print(get_confidence_score(text))