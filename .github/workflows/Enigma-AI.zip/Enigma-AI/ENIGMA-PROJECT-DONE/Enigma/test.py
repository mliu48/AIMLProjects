from tools import set_sequence

def is_same(a1,a2,l1):
    if a1 in l1 and a2 in l1:
        return True
    else:
        return False



list1 = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M'] 
list2 = ['N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'] 

l12 = list1 + list2
list3 = ['X', 'Y', 'Z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'] 
list4 = ['K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W'] 
l34 = list3+list4

list5 = ['P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'A', 'B'] 
list6 =  ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O'] 
l56 = list5+list6
'''
w1 = input()
w2 = input()
print(l12)
i1 = l12.index(w1)
i2 = l12.index(w2)
print(i1,i2)

def swap_connector(i1,i2,l12):
    if (i1 <= 12 and i2 <= 12):
        l12[i1+13],l12[i2+13] = l12[i2+13],l12[i1+13]
    elif (i1 <= 12 and i2 > 12):
        l12[i1+13],l12[i2-13] = l12[i2-13],l12[i1+13]
    elif (i1 > 12 and i2 <= 12):
        l12[i1-13],l12[i2+13] = l12[i2+13],l12[i1-13]
    else:
        l12[i1-13],l12[i2-13] = l12[i2-13],l12[i1-13]
    return l12[0:13],l12[13:]

print(l12)
print(l12[0:13],'\n',l12[13:])
'''
'''
a = [1,2,3,4,5,6]
b = a.push()
print(b,'\n',a)

puncuation = [',','.',';','"','!','/','[',']']
clear_text = 'Good Morning, I am William and I am from capital normal university high school'
clear_text = [i for i in clear_text if not i == ' ' ]
clear_text = [i for i in clear_text if i not in puncuation]
clear_text = [i.upper() for i in clear_text]
print(clear_text)
'''


from tools import str_to_list
ans = [1,2,3,4,5,6,7]
with open('input.txt','r') as f:
    for line in f:
        print(line)

