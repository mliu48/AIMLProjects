import numpy as np
import pandas as pd

from sklearn import pipeline
from sklearn.naive_bayes import MultinomialNB
from matplotlib import pyplot as plt
import os
for dirname, _, filenames in os.walk('/Language_Detection.csv'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

#data cleaning
import re
from nltk.corpus import stopwords
STOPWORDS = set(stopwords.words('english'))

def clean_text(self, text):
    clean_text = re.sub('[\[\]!@#$(),\n"%^*?\:;~`0-9]', ' ', text)   #remove bad symbols
    clean_text = clean_text.lower()   # lowercase
    clean_text = ' '.join(word for word in  clean_text.split() if word not in STOPWORDS)  # delete stopwords 
    
    return clean_text


data = pd.read_csv('Language_Detection.csv', encoding='utf-8')

print('Row:', data.shape[0])
print('Column:', data.shape[1])
print("Languages:", *data["Language"].unique())

print("Duplicate rows:", data.duplicated().sum())

data.drop_duplicates(inplace=True)

data['Language'] = data['Language'].apply(clean_text)
print(data['Language'])
data["Language"].value_counts().plot(kind='bar')
plt.show()
