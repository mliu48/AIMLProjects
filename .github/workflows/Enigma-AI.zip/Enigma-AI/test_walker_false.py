import gymnasium as gym
from stable_baselines3 import PPO,A2C
import os

os.environ['KMP_DUPLICATE_LIB_OK']='True'
models_dir = "models/Walker"
logdir = "logs"
if not os.path.exists(models_dir):
    os.makedirs(models_dir)
if not os.path.exists(logdir):
    os.makedirs(logdir)
env = gym.make("BipedalWalker-v3", hardcore=False)
env.reset()
'''
model = PPO('MlpPolicy', env, verbose=1, tensorboard_log=logdir)

TIMESTEPS = 100
iters = 0
for i in range(30):
    model.learn(total_timesteps=TIMESTEPS, reset_num_timesteps=False, tb_log_name="PPO")
    model.save(f"{models_dir}/{TIMESTEPS*i}")
'''

model_path = f"{models_dir}/333.zip"
model = PPO.load(model_path, env=env)
vec_env = model.get_env()

episodes = 5
TIMESTEPS = 111
iters = 0
for i in range(4000):
    model.learn(total_timesteps=TIMESTEPS, reset_num_timesteps=False, tb_log_name="PPO")
    model.save(f"{models_dir}/{TIMESTEPS*i}")
'''
for ep in range(episodes):
    obs = vec_env.reset()
    done = False
    while not done:
        action, _states = model.predict(obs)
        obs, rewards, done, info = vec_env.step(action)
        env.render()
        print(rewards)
'''