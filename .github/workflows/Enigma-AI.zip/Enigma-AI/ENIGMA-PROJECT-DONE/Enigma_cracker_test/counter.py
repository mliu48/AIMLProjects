file = open('test.txt','r')
cnt = 0
for i in file.readlines():
    cnt = cnt + 1
print(cnt/4)