import numpy as np
import pandas as pd
import re
from nltk.corpus import stopwords
from sklearn.preprocessing import LabelEncoder
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.preprocessing.sequence import pad_sequences
import joblib
from matplotlib import pyplot as plt
STOPWORDS = set(stopwords.words('english'))

# 创建清洗文本数据的函数
def clean_text(text):
    clean_text = re.sub('[\[\]!@#$(),\n"%^*?\:;~`0-9]', ' ', text)   #去除不需要的符号
    clean_text = clean_text.lower()   # 转换为小写
    clean_text = ' '.join(word for word in  clean_text.split() if word not in STOPWORDS)  # 删除停用词 
    
    return clean_text

def get_confidence_score(text, tokenizer, model, max_length):
    text_sequences = tokenizer.texts_to_sequences([text])
    text_padded = pad_sequences(text_sequences, maxlen=max_length)
    scores = model.predict(text_padded)[0]
    confidence_score = scores[np.argmax(scores)]
    return confidence_score

# 加载保存的模型
model = keras.models.load_model('language_detection_model.h5')
tokenizer = joblib.load('tokenizer.pkl')
encoder = joblib.load('encoder.pkl')
max_length = 100

# 使用训练好的模型对新样本进行预测
cnt = 0
file = open('output.txt','r')
lan = []
con = []
txt = []
#文件行数
for line in file:
    cnt += 1
while cnt>0:
    epoch = 1
    with open('output.txt','r') as f:
        for line in f:
            print('epoch:', epoch)
            epoch+=1
            text = line.lower()
            txt.append(text)
            #print(text)
            cleaned_text = clean_text(text)
            text_sequences = tokenizer.texts_to_sequences([cleaned_text])
            text_padded = pad_sequences(text_sequences, maxlen=max_length)
            y = np.argmax(model.predict(text_padded), axis=-1)
            prediction = encoder.classes_[y]

            #print(prediction)
            lan.append(str(prediction))
            score = get_confidence_score(cleaned_text, tokenizer, model, max_length)
            #print(score)
            con.append(score)
            cnt = cnt-1

print(lan)
max = 0
index = 0
for i in range(len(lan)):
    if lan[i].strip('[]').strip('\'') == 'English' and con[i] > max:
        max = con[i]
        index = i
print(max)
print(lan[index])
print(txt[index])
'''
for i in range(len(lan)):
    print(1)
    if lan[i].strip('[]').strip('\'') == 'English' and con[i] > 0.9:
        print(txt[i])
        print(lan[i])
        print(con[i])
'''