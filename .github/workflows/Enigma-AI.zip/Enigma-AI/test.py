import cv2
import numpy as np
img = np.zeros((500,500,3),dtype='uint8')

array_display = [[250,250]]

cv2.circle(img,(array_display[0][0],array_display[0][1]),10,(0,0,255),3)
cv2.imshow('a',img)
cv2.waitKey(1)

for i in range(250,3500,100):
    array_display.append([i,250])
    cv2.circle(img,(array_display[-1][0],array_display[-1][1]),10,(0,0,255),3)
    cv2.imshow('a',img)
    cv2.waitKey(1)