import sys
#1，2，3的排列
arr = [1,2,3]
#输出arr数组的全排列
def perm(arr):
    if len(arr) <= 1:
        return [arr]
    r = []
    for i in range(len(arr)):
        s = arr[:i] + arr[i+1:]
        p = perm(s)
        for x in p:
            r.append(arr[i:i+1] + x)
    return r

alphaet = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','q','p','r','s','t','u','v','w','x','y','z']


file = open('test.txt','w')
#输出arr数组的全排列
permed = perm(arr)
print(permed)
cnt = 0

for i in permed:
    for m in alphaet:
        for n in alphaet:
            for k in alphaet:
                 for o in range(0,26):
                    for p in range(0,26):
                        for t in range(0,13):
                            for q in range(0,13):
                                for b in range(0,13):
                                    for c in range(0,13):
                                        if o == p or o == t or o == q or o == b or o == c or p == t or p == q or p == b or p == c or t == q or t == b or t == c or q == b or q == c or b == c:
                                            continue
                                        cnt = cnt + 1
                                        print('Epoch:',cnt)
                                        #print(i,'\n',m+n+k,'\n',alphaet[o]+alphaet[p])
                                        file.write(str(i).replace(',','').replace('[','').replace(']','').replace(' ',''))
                                        file.write('\n'+m.upper()+n.upper()+k.upper()+'\n')
                                        file.write(alphaet[o].upper()+alphaet[p].upper()+alphaet[t].upper()+alphaet[q].upper()+alphaet[b].upper()+alphaet[c].upper()+'\n')
                                        file.write('\n')
                                        #print(i,'\n',m+n+k+l,'\n',alphaet[o]+alphaet[p])









'''
for i in permed: #[[]]
    for j in i: #[]
        print(j,end='')
        for k in alphaet:
            for l in alphaet:
                for m in alphaet:
                    #print(k+l+m,end='')
                    for n in range(0,13):
                        for o in range(13,26):
                            cnt = cnt + 1
                            if cnt == 3528972254808000:
                                sys.exit()
                            file.write(str(i).replace(',','').replace('[','').replace(']','').replace(' ',''))
                            file.write('\n'+k+l+m+'\n')
                            file.write(alphaet[n]+alphaet[o]+'\n')
                            file.write('\n')
                            #print(i,'\n',k+l+m,'\n',alphaet[n]+alphaet[o])
                                
    print()
'''
