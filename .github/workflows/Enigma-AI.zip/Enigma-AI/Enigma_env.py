import gym
from gym import spaces
import numpy as np
import random


def reach_destination(self,des_x,des_y):
    if self.x == des_x and self.y == des_y:
        return 1
    else:
        return 0
    
def collision_with_boundaries(x,y):
    if x>150 or x<0 or y<-150 or y>0 :
        return 1
    else:
        return 0

class EnigmaEnv(gym.Env):

    def __init__(self):
        super(EnigmaEnv, self).__init__()
        self.action_space = spaces.Discrete(4)
        self.observation_space = spaces.Box(low=-9, high=9, shape=(3,), dtype=np.int32)  

    

    def step(self, action):
        reward = self.get_reward()
        done = self.get_done()
        obs = self.get_observation()
        info = {}
        
    def reset(self):
        obs = self.get_observation()
        pass
        
        
        return obs, reward, done, info
    
    def get_observation(self):
        pass

    def get_reward(self):
        pass

    def get_done(self):
        pass

    def render(self, mode='human'):
        pass
    
