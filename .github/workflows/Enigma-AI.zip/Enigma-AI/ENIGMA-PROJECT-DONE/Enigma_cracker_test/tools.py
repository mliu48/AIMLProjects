def list_move(l,n):
    cnt = 0
    for _ in range(len(l)):
        if cnt == n:
            break
        l.append(l[0])
        l.remove(l[0])
        cnt +=1
    return l

def list_reverse(l,n):
    cnt = 0
    for i in range(len(l)):
        if cnt == n:
            break
        l.insert(0,l.pop())
        cnt +=1
    return l

def set_sequence(f,s,t,l1,l2,l3):
    if f == 1 and s == 2 and t == 3:
        return l1,l2,l3
    elif f == 1 and s == 3 and t == 2:
        return l1,l3,l2
    elif f == 2 and s == 1 and t == 3:
        return l2,l1,l3
    elif f == 2 and s == 3 and t == 1:
        return l3,l1,l2
    elif f == 3 and s == 2 and t == 1:
        return l3,l2,l1
    elif f == 3 and s == 1 and t == 2:
        return l2,l3,l1
    else:
        return
    
def str_to_list(clear_text):
    puncuation = [';','"','!','/','(',')',';',':','''''','1','2','3','4','5','6','7','8','9','[',']','\n']
    #alphabet = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O',
                #'P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','s','t','u','v','w','x','y','z',' ',',','\n']
    comma = [',']
    clear_text = [i for i in clear_text]
    clear_text = [i for i in clear_text if i not in puncuation]
    clear_text = [i.upper() for i in clear_text]
    return clear_text

def swap_connector(i1,i2,l12):
    if (i1 <= 12 and i2 <= 12):
        l12[i1+13],l12[i2+13] = l12[i2+13],l12[i1+13]
    elif (i1 <= 12 and i2 > 12):
        l12[i1+13],l12[i2-13] = l12[i2-13],l12[i1+13]
    elif (i1 > 12 and i2 <= 12):
        l12[i1-13],l12[i2+13] = l12[i2+13],l12[i1-13]
    else:
        l12[i1-13],l12[i2-13] = l12[i2-13],l12[i1-13]
    return l12[0:13],l12[13:]

