import math
import random
import turtle
import cv2
import gymnasium as gym
from gym import spaces
import numpy as np

def reach_destination(agent_position,des_x,des_y):
    if agent_position[0][0] == des_x and agent_position[0][1] == des_y:
        return 1
    else:
        return 0
    
def collision_with_boundaries(x,y):
    if x>500 or x<0 or y>500 or y<0:
        return 1
    else:
        return 0

class Enigma(gym.Env):
    def __init__(self):
        super(Enigma, self).__init__()
        self.action_space = spaces.Discrete(4)
        self.observation_space = spaces.Box(low=-9, high=9, shape=(3,), dtype=np.int32)  

    def reset(self):
        self.img = np.zeros((500,500,3),dtype='uint8')
        self.agent_position = [[250,250]]
        self.apple_position = [random.randrange(1,50)*10,random.randrange(1,50)*10]
        self.reward = 0
        self.done = False
        self.apple_position = [random.randrange(1,50)*10,random.randrange(1,50)*10]
        self.agent_position = [[250,250]]
        self.direction = 0

        observation = [self.agent_position[0][0],self.agent_position[0][1],self.apple_position[0],self.apple_position[1],self.reward]
        observation = np.array(observation)
        return (observation)

    def step(self, action):
        self.img = np.zeros((500,500,3),dtype='uint8')
        cv2.circle(self.img,(self.x,self.y),10,(255,0,0),3)
        cv2.imshow('a',self.img)

        cv2.circle(self.img,(self.apple_position[0],self.apple_position[1]),10,(0,0,255),3)
        cv2.circle(self.img,(self.agent_position[0][0],self.agent_position[0][1]),10,(0,255,0),3)

        direction = action

        if direction == 0:
            self.agent_position[0][0] += 10
        elif direction == 1:
            self.agent_position[0][0] -= 10
        elif direction == 2:
            self.agent_position[0][1] += 10
        elif direction == 3:
            self.agent_position[0][1] -= 10
        
        self.reward = 0
        if collision_with_boundaries(self.agent_position[0][0],self.agent_position[0][1]) == 1:
            self.reward = -10
            self.done = True
        elif reach_destination(self.agent_position,self.apple_position[0],self.apple_position[1]) == 1:
            self.reward = 10
            self.done = True
        else:
            self.reward = math.sqrt((self.agent_position[0][0]-self.apple_position[0])**2 + (self.agent_position[0][1]-self.apple_position[1])**2)

        info = {}

        observation = [self.agent_position[0][0],self.agent_position[0][1],self.apple_position[0],self.apple_position[1],self.reward]
        observation = np.array(observation)
        return observation, self.reward, self.done, info


        

        
