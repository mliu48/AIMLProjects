from enigma_vtest import run
from operation import operate

file = open('test 2.txt','r')
out = open('conf.txt','w')
cnt = 0
epoch = 0
num = []
alpha1 = []
alpha2 = []
ret = []
for i in file.readlines():
    cnt += 1
    if len(num) != 0 and len(alpha1) != 0 and len(alpha2) != 0:
        ret.append(num)
        ret.append(alpha1)
        ret.append(alpha2)
        run(ret)
        num = []
        alpha1 = []
        alpha2 = []
        ret = []
        epoch += 1
        print('Epoch:',epoch)
        if epoch == 10000:
            break

    if cnt %4 == 1 or cnt == 1:
        num.append(i)
    elif cnt %4 == 2 or cnt == 2:
        alpha1.append(i)
    elif cnt %4 == 3 or cnt == 3:
        alpha2.append(i)
    


file.close()
out.close()
operate(10)