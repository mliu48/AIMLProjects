from stable_baselines3 import PPO
import gymnasium as gym
from minigrid.wrappers import ImgObsWrapper
from stable_baselines3 import PPO,A2C,DDPG

import os

os.environ['KMP_DUPLICATE_LIB_OK']='True'
models_dir = "models/Grid"
logdir = "logs"
if not os.path.exists(models_dir):
    os.makedirs(models_dir)
if not os.path.exists(logdir):
    os.makedirs(logdir)


env = gym.make("MiniGrid-Empty-160x160-v0",render_mode='human')
env = ImgObsWrapper(env)
env.reset()
model = PPO('MlpPolicy', env, verbose=1, tensorboard_log=logdir)
model.learn(total_timesteps=100)
'''
First Time Use
TIMESTEPS = 100
iters = 0
for i in range(30):
    model.learn(total_timesteps=TIMESTEPS, reset_num_timesteps=False, tb_log_name="PPO")
    model.save(f"{models_dir}/{TIMESTEPS*i}")
'''

model_path = f"{models_dir}/14430.zip"
model = PPO.load(model_path, env=env)
vec_env = model.get_env()

episodes = 5
TIMESTEPS = 111
iters = 0
for i in range(150):
    model.learn(total_timesteps=TIMESTEPS, reset_num_timesteps=False, tb_log_name="PPO")
    model.save(f"{models_dir}/{TIMESTEPS*i}")

