file = open('output.txt','r')
output = open('output_operated.txt','w')

line = 1
def operate(s):
    global line
    for i in file.readlines():
        if line % s == 1 and line != 1:
            output.write('\n')
        output.write(i)
        line = line + 1

operate(1)