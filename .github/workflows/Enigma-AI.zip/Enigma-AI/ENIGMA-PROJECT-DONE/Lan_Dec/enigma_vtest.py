from tools import swap_connector
from tools import set_sequence
from tools import list_move,list_reverse
from tools import str_to_list
import sys
alphaet = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M','N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

list1 = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M']
list2 = ['N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
l12 = list1 + list2


list3 = ['X', 'Y', 'Z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']
list4 = ['K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W']
l34 = list3+list4

list5 = ['P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z','A','B']
list6 = ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L','M','N','O']
l56 = list5+list6

reflect_list = ['T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'A', 'B', 'C', 'D', 'E','F']
reflect_list_1 = ['G', 'H', 'I', 'J', 'K', 'L', 'M','N', 'O', 'P', 'Q', 'R', 'S']
lrr = reflect_list + reflect_list_1

ec1 = []
ec2 = []
ec3 = []
ec4 = []
ec5 = []
ec6 = []
ec_rl = [] 
ec_rl1 = []


Enc1 = {}
Se1 = ''
Enc2 = {}
Se2 = ''
Enc3 = {}
Se3 = ''
Reflector = {}

#齿轮起始字母 done
def def_swap(w,arr=[]):
    i = arr.index(w)
    list_move(arr,i)
def detect1(w):
    #print(list1,'\n',list2,'\n',list3,'\n',list4,'\n',list5,'\n',list6,'\n')
    if w in list1:
        def_swap(list2[list1.index(w)],list2)
        def_swap(w,list1)
    else:
        
        def_swap(list1[list2.index(w)],list1)
        def_swap(w,list2)
        
    #print(list1,'\n',list2,'\n',list3,'\n',list4,'\n',list5,'\n',list6,'\n')
def detect2(w):
    #print(list1,'\n',list2,'\n',list3,'\n',list4,'\n',list5,'\n',list6,'\n')
    if w in list3:
        def_swap(list4[list3.index(w)],list4)
        def_swap(w,list3)
    else:
        def_swap(list3[list4.index(w)],list3)
        def_swap(w,list4)
    #print(list1,'\n',list2,'\n',list3,'\n',list4,'\n',list5,'\n',list6,'\n')
def detect3(w):
    #print(list1,'\n',list2,'\n',list3,'\n',list4,'\n',list5,'\n',list6,'\n')
    if w in list5:
        def_swap(list6[list5.index(w)],list6)
        def_swap(w,list5)
    else:
        def_swap(list5[list6.index(w)],list5)
        def_swap(w,list6)

    #print(list1,'\n',list2,'\n',list3,'\n',list4,'\n',list5,'\n',list6,'\n')
def set_ini(ini):
    w1 = ini[0]
    detect1(w1)
    Se1 = w1
    w2 = ini[1]
    Se2 = w2
    detect2(w2)
    w3 = ini[2]
    Se3 = w3
    detect3(w3)

#齿轮顺序 done
def transformer(a1, a2):
    return a2,a1

def setseq(seq):
    f = seq[0]
    s = seq[1]
    t = seq[2]
    global list1,list2,list3,list4,list5,list6
    #print(list1,'\n',list2,'\n',list3,'\n',list4,'\n',list5,'\n',list6,'\n\n')
    l_12 = list1+list2; l_34 = list3+list4;l_56 = list5+list6
    l_12,l_34,l_56 = set_sequence(f,s,t,l_12,l_34,l_56)
    list1,list2 = l_12[0:13],l_12[13:]
    list3,list4 = l_34[0:13],l_34[13:]
    list5,list6 = l_56[0:13],l_56[13:]
    #print(list1,'\n',list2,'\n',list3,'\n',list4,'\n',list5,'\n',list6)
#交换接线板
def swap(w1,w2):
    global list1,list2,list3,list4,list5,list6,reflect_list,reflect_list_1
    if w1 in alphaet and w2 in alphaet:
        i1 = l12.index(w1)
        i2 = l12.index(w2)
        list1,list2 = swap_connector(i1,i2,l12)
        i1 = l34.index(w1)
        i2 = l34.index(w2)
        list3,list4 = swap_connector(i1,i2,l34)
        i1 = l56.index(w1)
        i2 = l56.index(w2)
        list5,list6 = swap_connector(i1,i2,l56)
        i1 = lrr.index(w1)
        i2 = lrr.index(w2)
        reflect_list,reflect_list_1 = swap_connector(i1,i2,lrr)
    else:
        print("Invalid input || 无效输入")
        return

def set(swapped):
    for i in range(0,4,2):
        w1 = swapped[i]
        w2 = swapped[i+1]
        swap(w1,w2)



#生成齿轮
def generate_Enc():
    #print(ec1,ec2)
    for i in range(0,13):
        Enc1[ec1[i]] = ec2[i]
        Enc1[ec2[i]] = ec1[i]

        Enc2[ec3[i]] = ec4[i]
        Enc2[ec4[i]] = ec3[i]

        Enc3[ec5[i]] = ec6[i]
        Enc3[ec6[i]] = ec5[i]

        Reflector[ec_rl[i]] = ec_rl1[i]
        Reflector[ec_rl1[i]] = ec_rl[i]
    #print(Enc1)
#转动条件判定，完善
ans = []
def encryption(text):
    global ec1,ec2,ec3,ec4,ec5,ec6,ec_rl,ec_rl1
    global ans
    text = str_to_list(text)
    F = True
    while len(text)>0:
        w = text.pop(0)
        #print(w)
        if w == ',' or w == ' ' or w == '.':
            ans.append(w)
        else:
        #print(w)
            if F == True:
                ec1 = list1.copy()
                ec2 = list2.copy()
                ec3 = list3.copy()
                ec4 = list4.copy()
                ec5 = list5.copy()
                ec6 = list6.copy()
                ec_rl = reflect_list.copy()
                ec_rl1 = reflect_list_1.copy()
                F = False
                generate_Enc()
                #print(ec1,'\n',ec2)
                #print(Enc1)
                w = Enc1[w]  #一号转子加密
                w = Enc2[w]  #二号转子加密
                w = Enc3[w] #三号转子加密
                w = Reflector[w] #反射器加密
                w = Enc3[w] #三号转子加密
                w = Enc2[w]  #二号转子加密
                w = Enc1[w]  #一号转子加密
                #print(w)
                ans.append(w)
                #print(ec1,'n\n')
                ec1 = list_move(ec1,1) #一号转子移动
                #print(ec1,'\n\n')
                #list_move(ec2,1) 
            else:
                generate_Enc()
                #print(ec1,'\n',ec2)
                #print(Enc1)                
                #print(w,'->')
                w = Enc1[w]  #一号转子加密
                #print(w,'->')
                w = Enc2[w]  #二号转子加密
                #print(w,'->')
                w = Enc3[w] #三号转子加密
                #print(w,'->')  
                w = Reflector[w] #反射器加密
                #print(w,'->')  
                w = Enc3[w] #三号转子加密
                #print(w,'->')  
                w = Enc2[w]  #二号转子加密
                #print(w,'->') 
                w = Enc1[w]  #一号转子加密
                #print(w)
                ans.append(w)
                #print(ec1,'n\n')
                ec1 = list_move(ec1,1) #一号转子移动
                #print(ec1,'\n\n')
                #list_move(ec2,1) 

                if ec1[0] == Se1: #一号转子到达A时，二号转子移动
                    list_move(ec3,1)
                    #list_move(ec4,1)

                    if ec3[0] == Se2: #二号转子到达X时，三号转子移动
                        list_move(ec5,1)
                        #list_move(ec6,1)

                        if ec5[0] == Se3:
                            list_move(ec_rl,1)
                            #list_move(ec_rl1,1)

if __name__ == '__main__':
    with open('config.txt','r') as f:
        seq = f.readline()
        seq = seq.split(',')
        seq = [int(i) for i in seq]
        ini = f.readline()
        ini = ini.split(',')
        ini = [i.strip() for i in ini]
        swapped = f.readline()
        swapped = swapped.split(',')
        swapped = [i.strip() for i in swapped]
    #seq = [3,1,2]
    #ini = ['C','H','A']
    #swapped = ['H','A','C','D','I','G']
    setseq(seq)
    set_ini(ini)
    set(swapped)
    clear_text = ''
    with open('input.txt','r') as f:
        for line in f:
            clear_text = clear_text + '\n' + line

    #print(clear_text)

    #clear_text = 'Hello, I am William and I am from capital normal university high school'
    encryption(clear_text)

    with open('output.txt','w') as f:
        for i in ans:
            if i == '.':
                f.write(i+'\n')
                continue
            f.write(i)